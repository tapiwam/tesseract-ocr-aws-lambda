# tesseract-ocr-aws-lambda
Running Tesseract OCR using AWS lambda
